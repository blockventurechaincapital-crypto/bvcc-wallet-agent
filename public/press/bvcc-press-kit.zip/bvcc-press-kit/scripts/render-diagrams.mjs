import { chromium } from 'playwright'
import { existsSync, readdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { homedir } from 'os'
// Diagrams live next to this folder: ../diagrams
const dir=join(dirname(fileURLToPath(import.meta.url)),'..','diagrams')
const cache=join(homedir(),'.cache','ms-playwright')
const b=readdirSync(cache).filter(d=>d.startsWith('chromium-')).sort((a,z)=>Number(z.split('-')[1])-Number(a.split('-')[1]))
let exe; for(const x of b){const p=join(cache,x,'chrome-linux64','chrome'); if(existsSync(p)){exe=p;break}}
const br=await chromium.launch({executablePath:exe})
for (const [f,w,h] of [['permission-flow',1200,520],['three-approaches',1200,560]]) {
  const p=await br.newPage({viewport:{width:w,height:h},deviceScaleFactor:2})
  await p.goto('file://'+join(dir,f+'.svg'))
  await p.waitForTimeout(600)
  await p.screenshot({path:join(dir,f+'.png')})
  await p.close(); console.log('rendered',f)
}
await br.close()
