# FACTS — every number in this kit, with where it comes from

Rule for this kit: if a number is here, a reader can check it without asking us. If it
can't be checked, it doesn't ship. Anything a journalist quotes should trace back to a
file in a public repo, an address on a block explorer, or a command they can run.

Last verified: 2026-08-04, against `bvcc-wallet-agent` commit `4651a03`.

---

## Identity

| Field | Value |
|---|---|
| Product name | BVCC Agent Wallet |
| Publisher | BlockVenture Chain Capital (BVCC) — a Web3 brand/project, **not an incorporated company** |
| Status | Public beta. Experimental. Not externally audited. |
| License | GPL-3.0-or-later (app + contracts) · MIT (both npm packages) |
| Site | https://bvccwallet.blockventurechaincapital.com |
| Contact | contact@blockventurechaincapital.com |
| GitHub org | https://github.com/blockventurechaincapital-crypto |
| LinkedIn | https://www.linkedin.com/company/blockventure-chain-capital/ |
| Demo video | https://www.youtube.com/watch?v=dWUTaWBk68A |

## Code and tests

| Number | What | How to check |
|---|---|---|
| **312** | Foundry tests on the V4 contracts (unit, fork, fuzz) | `cd contracts && forge install && forge test` |
| 22 | test files, 5,836 lines | `contracts/test/` |
| 5 | fuzz tests | grep `testFuzz_` in `contracts/test/` |
| 11 | fork tests across 2 fork suites | `AaveIntegration.t.sol`, `LegacyV2ReentrancyFork.t.sol` |
| **189** | SDK test cases (vitest) | `bvcc-agent-sdk`, `npm test` |
| 9 | contracts in `contracts/src/`, 1,876 lines | `contracts/src/` |
| 24,541 / 24,576 | agent factory runtime bytecode vs the EIP-170 ceiling — **35 bytes of headroom** | `forge build --sizes` |
| 26,009 | lines of TypeScript in the app (138 files) | `app/ components/ lib/` |

Solidity `0.8.36`, `via_ir = true`, `evm_version = "cancun"`, `optimizer_runs = 50`.
The version is pinned deliberately: it skips the via-IR pipeline bug range 0.8.28–0.8.33.

## The MCP surface

| Number | What |
|---|---|
| **53** | tools in the catalog — 12 read, 15 simulate, 26 write |
| 18 / 19 / 14 / 2 | by module: core / aave / lp / guides |
| **27** | tools exposed when `BVCC_MCP_READONLY=true` (every write disappears) |
| 4 | operating guides exposed as MCP prompts |
| 24 | on-chain custom errors decoded into plain language by the SDK (`src/errors.ts`) |

Check it: `npx -y @bvcc/agent-mcp` and list the tools. `BVCC_MCP_MODULES=core` narrows to 20.
Counts are asserted in `bvcc-agent-mcp/test/expected-surface.mjs`, so they can't silently drift.

npm: `@bvcc/agent-sdk` 0.2.2 · `@bvcc/agent-mcp` 0.2.2
MCP Registry id: `com.blockventurechaincapital/bvcc-agent-wallet`
Listed in: MCP Registry, Glama, mcp.so, TensorBlock.

## Deployment

Six networks. Same address everywhere, because the factories are deployed with CREATE2
from a fixed salt (`0x42564343` is ASCII "BVCC").

| Contract | Address (identical on all 6 chains) |
|---|---|
| BVCCSmartWalletFactoryV4 | `0xfd105197109244483b5f870501326E6faec9F93c` |
| BVCCAgentWalletFactoryV4 | `0xf3A61F9d64d45362E149A111289546523BCd26a6` |
| BVCCValidatorRegistry | `0x5e371D54AC97a57B0a99145Ed04A3c9fA07850C2` |
| BVCCHookRegistry | `0x551C6e7ABdA04a110790888e711198f25621b066` |
| EntryPoint (OZ v0.9) | `0x433709009B8330FDa32311DF1C2AFA402eD8D009` |

Chains: Ethereum (1) · BNB Chain (56) · Polygon (137) · Base (8453) · Arbitrum One (42161).
Active testnet: Arbitrum Sepolia (421614).

All verified on their explorers. Per-chain validator addresses are in `contracts/deployments/`
(18 JSON manifests, each with the codehash).

Roles are split on purpose: the deployer (`0xA3e06B…6617D`) holds no privileges, the
kill-switch owner (`0x3145Bd…A4c`) is a hardware wallet, and the fee wallet
(`0x3e3eb0…07D4`) is neither.

## Limits the contract enforces

Per agent: period budget with auto-rollover · daily limit · per-transaction cap · total
budget · per-token daily and total budgets · allowed token list · allowed protocol list ·
recipient whitelist (max 20) · expiry · instant pause. `0` means unlimited, and an empty
list means unrestricted — both are deliberate, not oversights.

Agents must be EOAs (`agent.code.length == 0`). An agent can never call the wallet itself.

For DeFi calls the wallet goes further and pins individual calldata arguments. A Uniswap
swap routed through the Universal Router has to have the recipient pinned to the wallet
and the command bytes matched exactly, or it reverts with `PinnedArgMismatch()`. So an
authorized agent can swap, but it cannot swap to an address that isn't yours.

Recovery: 2-of-3 guardians, 48-hour timelock, cancellable by the owner. Completing a
recovery pauses every agent.

Validator and hook registries also run on a 48-hour timelock, so adding a new protocol is
visible on-chain for two days before it can take effect.

## Fees

0.05% on personal wallet transactions, 0.15% on agent transactions. Charged on-chain by
the contract, denominator 1,000,000 (numerator 500 / 1500). Separate from gas and from the
agent's budget.

Worth being precise about: on a swap the fee is taken on the balance *increase* of the
token you receive. And the native side of a Uniswap v4 swap pays no fee, because the
snapshot mechanism can't see `address(0)`. Don't round this into "0.15% on everything".

## Security review

Internal. Four rounds, 2026-06 → 2026-07. Not an external audit, and we say so everywhere.

| Severity | Count | Status |
|---|---|---|
| Critical | 2 | both fixed |
| High | 3 | 2 fixed, **1 open (BVCC-03)** |
| Medium | 5 | 3 fixed, 1 open (interface), 1 accepted |
| Low | 1 | fixed |
| Informational | 2 | 1 mitigated, 1 accepted |

Thirteen findings in the current codebase, plus two closed in superseded generations. Nine
are fixed in bytecode that is deployed and verified on all six networks; seven of those
needed a bytecode change and shipped together as V4.

**BVCC-03 is open.** Where the owner has already granted a token allowance to a protocol,
anchoring a call's destination does not bound its value — so a compromised agent key can
be worth more than its budget. The mitigation is to hold zero standing allowances before
authorizing an agent that can reach that protocol. It is in the report, and it should be
in any honest write-up.

Also worth stating plainly: **a deployed wallet cannot be upgraded in place.** Wallets
still on V1, V2 or V3 run the old bytecode, including the critical BVCC-01, until their
owners migrate.

Report: 44 pages (EN) / 46 pages (ES), both linked below.

## Proof it works on mainnet

| What | Evidence |
|---|---|
| Agent swap via Universal Router, Arbitrum One | tx `0x6f831b37…3bc0` — gas 419,124, −0.100000 USDC, fee 0.000000078468831120 WETH = 0.15% exactly |
| Full Aave v3 cycle by the agent, Arbitrum One | supply → borrow → repay → withdraw, position closed |
| Uniswap v4 LP cycle, Arbitrum One | ETH/USDC native pool, tokenId 190877, mint → collect → decrease → burn |
| Adversarial attempt blocked | revert selector `0xaa53a959` = `PinnedArgMismatch()` |

Measured gas: `createWallet` 4,548,977 · `authorizeAgent` 166,803 · `setCallPolicy` 25,912 ·
`executeAsAgent` (DeFi call) 64,758. Harness: `contracts/test/GasBench.t.sol`.

## Product surface

7 documentation pages · 7 legal pages · 19 curated dApps across 7 categories · 6 chains ·
2 languages (EN/ES, full parity, ~823 strings each) · 22 i18n namespaces · 7 agent
capability presets (`swap`, `swapNative`, `swapV4`, `provideLiquidityV3`,
`provideLiquidityV4`, `aaveLend`, `aaveUnwind`).

---

## Numbers that are wrong in the repos — do not quote these

Found while assembling this kit. They contradict the live code and should be corrected.

| Stale claim | Where it lives | Reality |
|---|---|---|
| "264 Foundry tests" + V3 factory addresses listed as live | `docs/contracts.md` | 312 tests; V4 factories. The README in the same repo says 312, so the repo contradicts itself |
| "10 tests" and V1/V2 contracts only | `test_solidity/README.md` | 312 tests, V4 |
| "98/98 tests", `BVCCSmartWalletV1`, "target mainnet: Base" | `github/HACKATHON.md` | 312 tests, V4, five mainnets live |
| Factory addresses `0x230b…BdEf1` / `0x8D9e…F054c` | monorepo `README.md` | Those are the dead V2 factories |
| "Next.js 15" | monorepo `README.md` | 16.2.7 |
| "293 bytes of factory margin" | `foundry.toml` comment | 35 bytes |
| "512x512" agent portraits | `public/agents/README.txt`, `lib/agentAvatars.ts` | 1254×1254 |

## Links

- Site — https://bvccwallet.blockventurechaincapital.com
- Docs — https://bvccwallet.blockventurechaincapital.com/docs
- Connect an AI over MCP — https://bvccwallet.blockventurechaincapital.com/docs/connect-ai
- How agent permissions work — https://bvccwallet.blockventurechaincapital.com/docs/agent-permissions
- Security report (EN) — https://bvccwallet.blockventurechaincapital.com/audits/BVCC-Agent-Wallet-Security-Report.pdf
- Informe de seguridad (ES) — https://bvccwallet.blockventurechaincapital.com/audits/BVCC-Agent-Wallet-Informe-Seguridad.pdf
- Wallet + contracts — https://github.com/blockventurechaincapital-crypto/bvcc-wallet-agent
- MCP server — https://github.com/blockventurechaincapital-crypto/bvcc-agent-mcp
- SDK — https://github.com/blockventurechaincapital-crypto/bvcc-agent-sdk
- npm — https://www.npmjs.com/package/@bvcc/agent-mcp · https://www.npmjs.com/package/@bvcc/agent-sdk
- Demo — https://www.youtube.com/watch?v=dWUTaWBk68A
- Machine-readable summary — https://bvccwallet.blockventurechaincapital.com/llms.txt
