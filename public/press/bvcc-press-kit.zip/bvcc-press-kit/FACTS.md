# FACTS — every number in this kit, with where it comes from

Rule for this kit: if a number is here, a reader can check it without asking us. If it
can't be checked, it doesn't ship. Anything a journalist quotes should trace back to a
file in a public repo, an address on a block explorer, or a command they can run.

Last verified: 2026-11-11, against `bvcc-wallet-agent` commit `479d525` (tag `v1.2.0`).

---

## Identity

| Field | Value |
|---|---|
| Product name | BVCC Agent Wallet |
| Publisher | BlockVenture Chain Capital (BVCC) — a Web3 brand/project, **not an incorporated company** |
| Status | Public beta. Experimental. Not externally audited. |
| License | GPL-3.0-or-later (app + contracts) · MIT (both npm packages) |
| Site | https://bvccwallet.blockventurechaincapital.com |
| Contact | contact@blockventurechaincapital.com |
| GitHub org | https://github.com/blockventurechaincapital-crypto |
| LinkedIn | https://www.linkedin.com/company/blockventure-chain-capital/ |
| Demo video | https://www.youtube.com/watch?v=dWUTaWBk68A |

## Code and tests

| Number | What | How to check |
|---|---|---|
| **191** | Foundry tests on the V5 contracts (145 local, 46 on network forks), including invariants over 128,000 random action sequences | `cd contracts-v5 && forge test` |
| **503** | contract tests counting the V4 suite as well (312 on V4) | `cd contracts && forge install && forge test` |
| 22 | test files, 5,836 lines | `contracts/test/` |
| 5 | fuzz tests | grep `testFuzz_` in `contracts/test/` |
| 11 | fork tests across 2 fork suites | `AaveIntegration.t.sol`, `LegacyV2ReentrancyFork.t.sol` |
| **256** | SDK test cases (vitest) | `bvcc-agent-sdk`, `npm test` |
| 9 | contracts in `contracts/src/`, 1,876 lines | `contracts/src/` |
| 22,604 / 24,576 | V5 agent wallet runtime bytecode vs the EIP-170 ceiling — **1,972 bytes of headroom** | `cd contracts-v5 && forge build --sizes` |
| 26,009 | lines of TypeScript in the app (138 files) | `app/ components/ lib/` |

Solidity `0.8.36`, `via_ir = true`, `evm_version = "cancun"`, `optimizer_runs = 50`.
The version is pinned deliberately: it skips the via-IR pipeline bug range 0.8.28–0.8.33.

## The MCP surface

| Number | What |
|---|---|
| **57** | tools in the catalog — 12 read, 17 simulate, 28 write |
| 22 / 19 / 14 / 2 | by module: core / aave / lp / guides |
| **29** | tools exposed when `BVCC_MCP_READONLY=true` (every write disappears) |
| 4 | operating guides exposed as MCP prompts |
| 24 | on-chain custom errors decoded into plain language by the SDK (`src/errors.ts`) |

Check it: `npx -y @bvcc/agent-mcp` and list the tools. `BVCC_MCP_MODULES=core` narrows to 24.
Counts are asserted in `bvcc-agent-mcp/test/expected-surface.mjs`, so they can't silently drift.

npm: `@bvcc/agent-sdk` 0.4.0 · `@bvcc/agent-mcp` 0.4.0 (both support wallet V5)
MCP Registry id: `com.blockventurechaincapital/bvcc-agent-wallet`
Listed in: MCP Registry, Glama, mcp.so, TensorBlock.

## Deployment

Six networks. Same address everywhere, because everything is deployed with CREATE2.
New wallets are **V5**; V4 wallets keep working.

| V5 contract | Address (identical on all 6 chains) |
|---|---|
| BVCCWalletFactoryV5 (personal wallets) | `0x2672951DC1E3f865BA6Fc98e5509dc4B23B260a2` |
| BVCCWalletFactoryV5 (agent wallets) | `0xE36fb66c21C38536454C1a58fBC5EB1Cb455aD52` |
| BVCCValidatorRegistryV5 | `0x7269334AE74DCE4e607eec36268383DD35f28350` |
| BVCCHookRegistryV5 | `0xEaEaC7F6071f7F576Be2aD97898Dd0c0F51BE78A` |
| EntryPoint (v0.9) | `0x433709009B8330FDa32311DF1C2AFA402eD8D009` |

Chains: Ethereum (1) · BNB Chain (56) · Polygon (137) · Base (8453) · Arbitrum One (42161).
Active testnet: Arbitrum Sepolia (421614).

All 72 V5 contracts (7 core + 5 validators per network) are source-verified on their
explorers, and the 30 validators are active in the registry. The full list, with every
validator address per network, is in the security report and on the docs' Contract Reference.

Previous generation, V4: factories `0xfd105197109244483b5f870501326E6faec9F93c` (personal) and
`0xf3A61F9d64d45362E149A111289546523BCd26a6` (agent).

Roles are split on purpose: the deployer holds no privileges, the governance owner is a
hardware wallet, and the fee wallet (`0x3e3eb0…07D4`) is neither.

## Limits the contract enforces

Per agent, on wallet V5: period budget · daily limit · per-batch cap · total budget ·
per-token batch, daily and total budgets · allowed tokens (max 50) · allowed protocols
(max 20) · recipient whitelist (max 20) · expiry, required and at most one year away ·
pause for that agent alone, or for all of them. `0` and an empty list allow **nothing**.

The core idea of V5: the wallet measures what leaves. Before and after every agent batch it
reads the balance of each token involved, and whatever left is charged against the agent's
limits, fee included — whatever route the agent took and whatever approvals the owner gave
in the past. A token that is not on the agent's list and goes down makes the batch revert.
Approvals the agent makes are reset when the batch ends.

Every DeFi call also passes an on-chain validator for that protocol (Universal Router,
Uniswap v4 and v3 positions, Aave v3, wrapped native). For a Universal Router swap, the
command bytes must match exactly and every recipient must be the wallet. Aave actions must
leave a health factor of at least 1.2.

Agents must be EOAs, checked at every call. An agent can never call the wallet itself.

Recovery: 2-of-3 guardians vote for a specific new passkey; a 48-hour wait, cancellable by
the owner. Executing a recovery pauses every agent.

Validator and hook registries run on a 48-hour timelock, so widening what agents can do is
visible on-chain for two days before it can take effect.

## Fees

0.05% on personal wallet transactions, 0.15% on agent wallets. Charged on-chain by the
contract, denominator 1,000,000 (numerator 500 / 1500). Separate from gas.

On wallet V5 the agent fee is charged on what an agent batch takes out of the wallet, in the
same token, on top of the amount, and it counts inside the agent's limits. Don't round this
into "0.15% on everything": the owner's own operations on a personal wallet pay 0.05%.

## Security review

Internal, covering every generation from V1 (2026-06) to V5 (2026-11). The five V5 review
rounds and the red-team exercise were run with AI analysis tools. Not an external audit, and
we say so everywhere.

| Severity | Count | Status on V5 |
|---|---|---|
| Critical | 2 | both fixed |
| High | 13 | 12 fixed, 1 accepted |
| Medium | 10 | 8 fixed, 2 accepted |
| Low | 3 | 2 fixed, 1 accepted |
| Informational | 2 | both fixed |

Thirty findings with identifiers: `BVCC-01` … `BVCC-13` from the review of V4 and earlier,
and `BVCC-14` … `BVCC-30` from the V5 rounds, all handled before V5 was deployed. **Nothing is
open on V5.** Four findings are accepted as stated trust assumptions: validators must be
immutable, approved Uniswap v4 hooks and the tokens an owner allows are trusted, and the
wallet only measures tokens a validator declares.

**BVCC-03 is still open on V4 wallets.** Where the owner has already granted a token
allowance to a protocol, a compromised agent key can be worth more than its budget. V5
closes it by measuring outflows. A deployed wallet cannot be upgraded in place, so wallets
still on V1 to V4 run their old bytecode until their owners move to V5.

Report: 61 pages (EN) / 64 pages (ES), both linked below.

## Proof it works on mainnet

Run with a V4 agent wallet on Arbitrum One. On V5, the full agent battery ran on Arbitrum
Sepolia, and a V4 wallet was migrated to V5 on BNB Chain with one owner signature.

| What | Evidence |
|---|---|
| Agent swap via Universal Router, Arbitrum One | tx `0x6f831b37…3bc0` — gas 419,124, −0.100000 USDC, fee 0.000000078468831120 WETH = 0.15% exactly |
| Full Aave v3 cycle by the agent, Arbitrum One | supply → borrow → repay → withdraw, position closed |
| Uniswap v4 LP cycle, Arbitrum One | ETH/USDC native pool, tokenId 190877, mint → collect → decrease → burn |
| Adversarial attempt blocked | revert selector `0xaa53a959` = `PinnedArgMismatch()` |

Measured gas on V5: creating a wallet ~537,000 (V4: 4,548,977) · an agent batch ~142,000–148,000
with one token, ~956,000 worst case with 60 tokens measured. Harness: `contracts-v5/test/GasV5.t.sol`.

## Product surface

7 documentation pages · 7 legal pages · 19 curated dApps across 7 categories · 6 chains ·
2 languages (EN/ES, full parity, ~823 strings each) · 22 i18n namespaces · 7 agent
capability presets (`swap`, `swapNative`, `swapV4`, `provideLiquidityV3`,
`provideLiquidityV4`, `aaveLend`, `aaveUnwind`).

---

## Links

- Site — https://bvccwallet.blockventurechaincapital.com
- Docs — https://bvccwallet.blockventurechaincapital.com/docs
- Connect an AI over MCP — https://bvccwallet.blockventurechaincapital.com/docs/connect-ai
- How agent permissions work — https://bvccwallet.blockventurechaincapital.com/docs/agent-permissions
- Security report (EN) — https://bvccwallet.blockventurechaincapital.com/audits/BVCC-Agent-Wallet-Security-Report.pdf
- Informe de seguridad (ES) — https://bvccwallet.blockventurechaincapital.com/audits/BVCC-Agent-Wallet-Informe-Seguridad.pdf
- Wallet + contracts — https://github.com/blockventurechaincapital-crypto/bvcc-wallet-agent
- MCP server — https://github.com/blockventurechaincapital-crypto/bvcc-agent-mcp
- SDK — https://github.com/blockventurechaincapital-crypto/bvcc-agent-sdk
- npm — https://www.npmjs.com/package/@bvcc/agent-mcp · https://www.npmjs.com/package/@bvcc/agent-sdk
- Demo — https://www.youtube.com/watch?v=dWUTaWBk68A
- Machine-readable summary — https://bvccwallet.blockventurechaincapital.com/llms.txt
