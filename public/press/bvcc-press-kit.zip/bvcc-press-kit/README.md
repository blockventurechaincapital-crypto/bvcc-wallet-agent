# BVCC Agent Wallet — Press Kit

Everything needed to write about, film, or fact-check BVCC Agent Wallet.

Live version: **https://bvccwallet.blockventurechaincapital.com/press**
Questions: **contact@blockventurechaincapital.com**

A person reads that address. Happy to do interviews, walk through the contracts on a call,
or set a wallet up with you so you can watch an agent hit a limit and bounce off it.

---

## Start here

| If you have | Read |
|---|---|
| 60 seconds | `media-kit/BVCC-Agent-Wallet-Media-Kit.pdf` — the whole story on one page |
| 5 minutes | `boilerplate/boilerplate-en.md` — paste-ready copy, plus the words to avoid |
| You're fact-checking | `FACTS.md` — every number with how to verify it yourself |
| You want to see it move | https://www.youtube.com/watch?v=dWUTaWBk68A |
| You want to run it | `BVCC_MCP_READONLY=true npx -y @bvcc/agent-mcp` |

---

## Folder structure

```
bvcc-press-kit/
├── README.md                      you are here
├── FACTS.md                       every citable number + its provenance,
│                                  and a list of stale numbers NOT to quote
│
├── media-kit/
│   ├── BVCC-Agent-Wallet-Media-Kit.pdf        one page, English
│   ├── BVCC-Agent-Wallet-Media-Kit-ES.pdf     one page, Spanish
│   ├── BVCC-Agent-Wallet-Security-Report.pdf  full internal review, 44 pp, EN
│   ├── BVCC-Agent-Wallet-Informe-Seguridad.pdf  46 pp, ES
│   ├── media-kit-en.html                      source for the EN one-pager
│   ├── media-kit-es.html                      source for the ES one-pager
│   └── render-pdf.mjs                         HTML → PDF (headless Chromium)
│
├── boilerplate/
│   ├── boilerplate-en.md          14 / 46 / 98-word descriptions, the problem
│   │                              statement, founder quote, required attribution,
│   │                              and the list of words that would be wrong
│   └── boilerplate-es.md          same in Spanish, written natively
│
├── logos/
│   ├── bvcc_w.png                 primary mark, transparent, 1254×1254
│   ├── bvcc_wallet.png            mark on solid dark, 1254×1254
│   └── networks/                  Ethereum, Arbitrum, Base, BNB, Polygon
│
├── diagrams/                      free to use with attribution
│   ├── three-approaches.svg/.png  private key vs signing server vs on-chain limits
│   └── permission-flow.svg/.png   what the contract checks, in order
│
├── screenshots/
│   ├── raw/                       full resolution, browser chrome removed
│   └── web/                       1600px wide, optimised for articles
│
└── scripts/
    ├── render-diagrams.mjs        SVG → 2x PNG
    └── capture-screenshots.mjs    re-shoot the app (see below)
```

---

## Licensing of these assets

The wallet and contracts are GPL-3.0-or-later. Both npm packages are MIT.

For this kit specifically: **use the logos, screenshots and diagrams freely in editorial
coverage.** No permission needed, no approval process, no request to see the piece first.
Attribution is appreciated and never required. The one thing to avoid is presenting the
mark in a way that implies BVCC endorsed or reviewed your article.

Do not recolor the logo, add effects to it, or stretch it. If you need it on a light
background, ask rather than inverting this one, and you will get a proper version.

---

## Please read this part

Three things get written about this project incorrectly, and all three are avoidable.

**It is not audited.** The security review is internal, done by the developer on his own
code. Four rounds, thirteen findings, all published. Nine are fixed in bytecode that is
deployed and verified on six networks. One high-severity finding is open with a documented
mitigation. "Internally reviewed" is accurate. "Audited" is not.

**BVCC is not a company.** It is a Web3 brand and project, not incorporated, not a bank or
broker or custodian, and it does not hold or recover anyone's funds.

**The agent can still spend its budget.** The point of the design is that a compromised
agent key is worth its remaining budget instead of the whole account. It is a blast-radius
reduction, not a guarantee that nothing can go wrong.

The full list of phrasings to avoid, with the reason each one is wrong, is at the bottom of
`boilerplate/boilerplate-en.md`.

---

## Regenerating things

The one-page PDFs:

```bash
npm i playwright && npx playwright install chromium
cd media-kit
node render-pdf.mjs        # English
node render-pdf.mjs es     # Spanish
node render-pdf.mjs all    # both
```

Edit the matching `.html` and re-run. The script warns if the layout spills past one page,
which is the only rule that document has.

The diagrams:

```bash
node scripts/render-diagrams.mjs
```

---

## Known gaps in this kit

Being straight about what is missing, so nobody wastes time looking for it.

- **The screenshots are dated.** They come from an earlier build: testnet balances, an older
  dashboard, and the agents screen before it was redesigned to show per-agent portraits and
  spend. They are honest images of the app, just not of this week's app. A fresh mainnet set
  needs the owner present to approve each action with a passkey.
- **No SVG logo.** Only raster, at 1254×1254. Fine up to about 600px on screen; not enough
  for large print.
- **No landscape OG/social card.** The site currently shares a square logo, which social
  platforms crop badly.
- **No screenshots of the MCP side**, which is arguably the most interesting part: an
  assistant calling the wallet and being refused by the contract.
