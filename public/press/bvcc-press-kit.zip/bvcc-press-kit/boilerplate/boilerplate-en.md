# Boilerplate — English

Copy these as-is. They are written to be pasted into an article without editing.

---

## One line (14 words)

A non-custodial wallet that gives an AI agent spending limits the contract itself enforces.

## Short (46 words)

BVCC Agent Wallet is an open-source, non-custodial smart wallet built on ERC-4337 and
passkeys. It lets you hand an AI agent its own wallet with limits written into the
contract: a budget, which tokens it may touch, which protocols it may call, and where it
may send funds.

## Medium (98 words)

BVCC Agent Wallet is an open-source, non-custodial smart wallet that lets you delegate
transactions to an AI agent without handing it a private key that can drain you. You sign
in with a passkey. The agent gets its own keypair and a permission envelope enforced by the
smart contract: period budget, allowed tokens, allowed protocols, recipient whitelist,
expiry, and a pause switch. Any MCP client (Claude, Cursor, LM Studio, Hermes) connects in
one command and receives 53 tools for transfers, Uniswap swaps, Aave lending and liquidity
positions. It runs on five mainnets. It is in public beta.

## The problem, stated plainly

To let an AI agent transact today, you give it a private key. A private key has no ceiling.
If the agent is prompt-injected, hallucinates a destination, or the key leaks out of a
config file, everything in that wallet is gone, and nothing on-chain was in a position to
stop it.

The usual answer is to put a server in the middle that decides which transactions to sign.
That works, and it moves the problem. Now you trust the server, and whoever runs it can
sign whatever it likes.

BVCC puts the limits in the contract instead. The agent holds its own key and can sign
freely. The wallet refuses anything outside the envelope you set. A leaked agent key is
worth its remaining budget, not the account.

## What is actually different

Most work on agent wallets stops at a spending cap. The harder problem is that a cap says
nothing about intent. An agent authorized to swap on Uniswap with a $500 budget can still
route that swap so the output lands in an attacker's address, and it never goes over $500.

So the wallet inspects the call itself. For a swap through Uniswap's Universal Router it
pins the recipient argument to your own wallet and matches the command bytes exactly.
Anything else reverts with `PinnedArgMismatch()`. The agent can trade. It cannot trade on
someone else's behalf. There are 34 adversarial tests and 42 validator tests behind that
check.

Adding a new protocol to the allowlist goes through a registry with a 48-hour timelock, so
the change sits visible on-chain for two days before it can take effect.

## Founder quote

"Every agent framework I looked at solves this off-chain. You run a server, the server
decides what to sign, and now the server is the thing that can rob you. I didn't want to be
that server. So the budget and the destination checks live in the contract, where I can't
override them either. If the agent tries to send funds somewhere I never approved, the
transaction just reverts. I like that I'm not in the loop."

— Founder, BlockVenture Chain Capital

## Try it read-only

```bash
BVCC_MCP_READONLY=true npx -y @bvcc/agent-mcp
```

Read-only mode exposes 27 of the 53 tools and drops every write. It can read balances,
quote swaps and simulate transactions, and it cannot move anything. Reasonable way to look
around before pointing it at real funds.

## Status, said clearly

Public beta. Experimental software. The security review is internal, carried out by the
developer on his own code, and no independent party has audited it. Thirteen findings are
catalogued and published, nine are fixed in deployed bytecode, and one high-severity
finding is open with a documented mitigation. Use small amounts.

## Required attribution

BlockVenture Chain Capital is a Web3 brand and project. It is not an incorporated company,
a bank, a broker, an exchange, a custodian, or a regulated financial institution. It does
not hold, control, or recover user funds.

## Words to avoid when writing about this

Each of these would be factually wrong, which is why they're listed.

| Don't write | Because |
|---|---|
| "secure", "safe", "protected funds" | It is unaudited beta software. |
| "audited" | The review is internal. Say "internally reviewed" or "self-audited". |
| "company", "startup", "firm" | BVCC is a brand and project, not incorporated. |
| "institutional-grade", "production-ready" | Public beta. |
| "0.15% on everything" | The native side of a Uniswap v4 swap pays nothing. |
| "your keys never leave the device" | Say passkeys/WebAuthn, and that BVCC never receives keys. |
| "the AI can't steal your money" | It can spend up to its budget. That is what the budget is for. |
