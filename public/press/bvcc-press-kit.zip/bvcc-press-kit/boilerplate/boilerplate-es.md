# Boilerplate — Español

Cópialos tal cual. Están escritos para pegarse en un artículo sin retocar.

---

## Una línea

Una wallet no custodial que le pone a un agente de IA límites de gasto que hace cumplir el
propio contrato.

## Corto (48 palabras)

BVCC Agent Wallet es una smart wallet no custodial y de código abierto, construida sobre
ERC-4337 y passkeys. Permite darle a un agente de IA su propia wallet con límites escritos
en el contrato: un presupuesto, qué tokens puede tocar, a qué protocolos puede llamar y a
dónde puede enviar fondos.

## Medio (101 palabras)

BVCC Agent Wallet es una smart wallet no custodial y de código abierto que permite delegar
transacciones en un agente de IA sin entregarle una clave privada capaz de vaciarte. Tú
entras con una passkey. El agente recibe su propio par de claves y un margen de permisos
que hace cumplir el contrato: presupuesto por periodo, tokens permitidos, protocolos
permitidos, lista de destinatarios, caducidad y un botón de pausa. Cualquier cliente MCP
(Claude, Cursor, LM Studio, Hermes) se conecta con un comando y recibe 53 herramientas para
transferencias, swaps en Uniswap, préstamos en Aave y posiciones de liquidez. Funciona en
cinco mainnets. Está en beta pública.

## El problema, dicho sin adornos

Hoy, para que un agente de IA pueda transaccionar, le das una clave privada. Una clave
privada no tiene techo. Si al agente le cuelan un prompt injection, si alucina un destino o
si la clave se escapa de un fichero de configuración, todo lo que hubiera en esa wallet se
ha ido, y no había nada on-chain en posición de impedirlo.

La respuesta habitual es meter un servidor en medio que decida qué transacciones firmar.
Funciona, y desplaza el problema. Ahora confías en el servidor, y quien lo opere puede
firmar lo que le apetezca.

BVCC mete los límites en el contrato. El agente tiene su propia clave y puede firmar lo que
quiera. La wallet rechaza cualquier cosa fuera del margen que hayas fijado. Una clave de
agente filtrada vale lo que le quede de presupuesto, no la cuenta entera.

## Qué es realmente distinto

Casi todo el trabajo sobre wallets para agentes se queda en el tope de gasto. El problema
difícil es que un tope no dice nada sobre la intención. Un agente autorizado a hacer swaps
en Uniswap con 500 $ de presupuesto puede enrutar ese swap para que la salida acabe en la
dirección de un atacante, y en ningún momento se pasa de 500 $.

Así que la wallet inspecciona la llamada. En un swap por el Universal Router de Uniswap,
fija el argumento del destinatario a tu propia wallet y exige que los bytes de comando
coincidan exactamente. Cualquier otra cosa revierte con `PinnedArgMismatch()`. El agente
puede operar. No puede operar en beneficio de otro. Detrás de esa comprobación hay 34 tests
adversariales y 42 tests del validador.

Añadir un protocolo nuevo a esa lista pasa por un registro con timelock de 48 horas, así
que el cambio queda visible on-chain durante dos días antes de poder aplicarse.

## Cita del fundador

«Todos los frameworks de agentes que miré resuelven esto fuera de la cadena. Levantas un
servidor, el servidor decide qué se firma, y ahora el servidor es lo que te puede robar. No
quería ser ese servidor. Así que el presupuesto y las comprobaciones de destino viven en el
contrato, donde tampoco yo puedo saltármelos. Si el agente intenta mandar fondos a un sitio
que no aprobé, la transacción revierte y ya está. Me gusta no estar en medio.»

— Fundador, BlockVenture Chain Capital

## Pruébalo en modo lectura

```bash
BVCC_MCP_READONLY=true npx -y @bvcc/agent-mcp
```

El modo de solo lectura expone 27 de las 53 herramientas y quita todas las de escritura.
Puede leer saldos, cotizar swaps y simular transacciones, y no puede mover nada. Es una
forma razonable de echar un vistazo antes de apuntarlo a fondos reales.

## Estado, dicho claro

Beta pública. Software experimental. La revisión de seguridad es interna, hecha por el
propio desarrollador sobre su código, y ningún tercero independiente la ha auditado. Hay
trece hallazgos catalogados y publicados, nueve corregidos en bytecode ya desplegado, y uno
de severidad alta sigue abierto con su mitigación documentada. Usa cantidades pequeñas.

## Atribución obligatoria

BlockVenture Chain Capital es una marca y proyecto Web3. No es una empresa constituida, ni
un banco, ni un bróker, ni un exchange, ni un custodio, ni una entidad financiera regulada.
No guarda, controla ni recupera fondos de usuarios.

## Palabras que conviene evitar al escribir sobre esto

Cada una de estas sería falsa, y por eso están en la lista.

| No escribas | Porque |
|---|---|
| «seguro», «fondos protegidos» | Es software en beta sin auditar. |
| «auditado» | La revisión es interna. Di «revisado internamente» o «autoauditado». |
| «empresa», «startup», «compañía» | BVCC es una marca y proyecto, no está constituida. |
| «grado institucional», «listo para producción» | Beta pública. |
| «0,15 % en todo» | El lado nativo de un swap en Uniswap v4 no paga comisión. |
| «tus claves nunca salen del dispositivo» | Di passkeys/WebAuthn, y que BVCC nunca recibe claves. |
| «la IA no puede robarte» | Puede gastar hasta su presupuesto. Para eso está el presupuesto. |
